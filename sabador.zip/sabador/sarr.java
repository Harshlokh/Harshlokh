import java.util.*;
 
public class sarr
   {
   public static void main(String args[])
        {
           String Arr[] ={"harsh","Sam","Arya","khushi"};
           System.out.println("Printing Array");
             for(String x: Arr)
            {
              System.out.println(x);
                 }
              }
          }
