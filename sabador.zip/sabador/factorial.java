import java.util.*;

public class main {

    public static void main(String[] args) {
        
        Scanner si = new Scanner(System.in);
        
        System.out.println("Enter Number : ");
        int no = si.nextInt();
       int res=factorial(no); 
      System.out.println("Factorial is "+res);
    }
   
    static int factorial(int no)
   {
       int fact=1;
     while(no>0)
    {
       fact=fact*no;
       no--;
     }
     return fact;
        }
}
