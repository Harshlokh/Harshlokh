import java.util.*;

public class farr

  {
   public static void main(String args[])
      { 
          
          Float Arr[] ={12.3f,23.5f,12.6f};
         System.out.println("Printing array");
            for(int i=0;i<Arr.length;i++)
           {
              System.out.print(Arr[i]+"\t");   
              }
           }
     }