import java.util.*;
 
public class carr
   {
   public static void main(String args[])
        {
           char Arr[] ={'a','*','%','*'};
           System.out.println("Printing Array");
            for(int i=0;i<Arr.length;i++)
             {

                System.out.print(Arr[i]+"\t");
                   }
          System.out.println("Reversed Array");
          for(int i=3;i>=0;i--)
               {
                 System.out.print(Arr[i]+"\t");
                
                  }
              }
          }
