import java.util.*;

public class main
 {
public static void main (String args[])
 {
        int [] Arr={11,2,3,4};
        Scanner sc=new Scanner(System.in);
      for(int i=0;i<=Arr.length;i++)
   {
         System.out.println(Arr[i]+"\n");
        }
      }
          }